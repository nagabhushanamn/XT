import home from './home';
import login from './login';
import register from './register';

export {home, login, register};